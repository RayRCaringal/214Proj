#include "multitest.h"
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>


typedef struct _holder_args {
    int* array;
    int pArr;
    int token;
    int arrSize;
    int subArrSize;
    int ans;
} holder_args;


void* Searcher(void* args) {
    holder_args* arguments = args;
    int* arr = arguments -> array;
    int pOfThisArr = arguments -> pArr;
    int token = arguments -> token;
    int arrSize = arguments -> arrSize;
    int subArrSize = arguments -> subArrSize;

    int beginning  = pOfThisArr * subArrSize;

    int ending;
    if (arrSize < (pOfThisArr + 1) * subArrSize)
        ending = arrSize;
    else
        ending = (pOfThisArr + 1) * subArrSize;

    int z;
    for (z = beginning ; z < ending; z++) {
        if (*(arr + z) == token) {
   arguments -> ans = z;

            pthread_exit(&(arguments -> ans));
        }
    }

    z = -1;
    arguments -> ans = z;

    pthread_exit(&(arguments -> ans));
}

int multi_thread(int* arr, int token, int arrSize, int subArrSize)
{
    int threadCount = arrSize / subArrSize;
    if (arrSize % subArrSize != 0)
        threadCount++;

    pthread_t threads[threadCount];

    int i;
    for (i = 0; i < threadCount; i++) {
        holder_args* arguments = (holder_args*)malloc(sizeof(holder_args));
        arguments -> array = arr;
        arguments -> pArr = i;
        arguments -> token = token;
        arguments -> arrSize = arrSize;
     arguments -> subArrSize = subArrSize;

        pthread_create(&threads[i], NULL, Searcher, arguments);
    }

    int whereItsAt = -1;
    for (i = 0; i < threadCount; i++) {
        void* t;
        pthread_join(threads[i], &t);
        int* ans = (int*)t;

        if (*ans != -1)
          whereItsAt = *ans;
    }

    return whereItsAt;
}